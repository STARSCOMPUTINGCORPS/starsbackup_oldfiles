<?php

$variable=$_POST['message'];
echo "12345 $variable";


//echo "hi";
/*
function nick()
	{
	if(isset($_POST['message']))
	{
	$return='hello';
	return $return;
	}
	}
	*/
?>