<?php

class Config {

    public static $dbName = 'STARS';
    public static $dbUser = 'root';
    public static $dbPass = 'hcilab300';
    public static $dbHost = 'localhost';            
    public static $dateFormat = 'Y-m-d\TH-i-s'; // Standard XML time format.
    public static $password = 'hcilab300+';
}
