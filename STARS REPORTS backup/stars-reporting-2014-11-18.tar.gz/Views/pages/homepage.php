<?php Template::includeTemplate('html_header.php'); ?>
<div role="main" id="main">
  <?php Template::includeTemplate('html_navigation.php'); ?>
  
    <p>Select something from the navigation menu.</p>
	<?php Template::includeTemplate('html_dashBoard.php'); ?>
	  <br>
 
</div>
	<?php Template::includeTemplate('html_footer.php'); ?>
</div>

