<?php // Preload, cache resources ?>
<script type="text/javascript" src="/js/jquery.min.js"></script>
<script type="text/javascript" src="/js/jquery-ui-1.10.0.min.js"></script>
<script type="text/javascript" src="/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf-8" src="/js/TableTools.min.js"></script>
<script type="text/javascript"> $('#login-password').focus(); </script>
</body>
</html>
