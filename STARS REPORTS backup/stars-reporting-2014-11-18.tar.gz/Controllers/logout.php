<?php
session_destroy();