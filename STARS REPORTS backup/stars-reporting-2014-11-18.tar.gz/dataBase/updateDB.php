


<script type="text/javascript">
 <!--

var answer = confirm ("Please click on OK to confirm a Database update, or CANCEL to be directed to the report screen.")
if (!answer)
 window.location="http://ec2-23-23-32-35.compute-1.amazonaws.com/"
else
	{
	<?php echo "this should work";?>
	alert('put code to start db here');
	}
 // -->
 </script> 


