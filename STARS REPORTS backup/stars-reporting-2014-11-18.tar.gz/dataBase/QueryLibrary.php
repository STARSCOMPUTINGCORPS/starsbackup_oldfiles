<?php

class QueryLibrary
{
	/** 
	*  			Remote Queries Section (Currently Being Used)
	*
	*			Select statement to pull all users on STARS Community Website
	*			Note: Other queries will have to be run from the Specific Remote Queries Section below to get user information
	*			profile_id 3 = Student, 1 = Faculty, 5 = Alumnus, 0 = Other, 4 = Special  ??
	**/
	
	public static $user_all = 'SELECT userid AS user_id, name AS real_name, email, registerDate AS register_date, lastvisitDate AS last_visit_date, profile_id FROM `jos_community_users` INNER JOIN jos_users ON userid = jos_users.id ORDER BY user_id ASC';
	
	//This is to get all other user fields not available in above query
	
	public static $full_query = "SELECT * FROM `jos_community_fields_values` WHERE user_id = :user_id";
	
	public static $getMemberData = "SELECT `id`, `real_name`, `school`, `email` FROM `memberData` WHERE `user_id` = :user_id AND `real_name` = :real_name AND `school` = :school";

}
?>