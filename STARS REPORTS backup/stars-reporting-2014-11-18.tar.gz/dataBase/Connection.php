<?php

class Connection
{
	/**
	*		Note: An attempt to make variables easy to understand has been made.
	*		Example: $databaseLocal will name the Local database to be used
	*		Conversely, $databaseRemote will name the Remote database to be used
	*		And so on with the other variables.
	**/
	
	/**
	*		Local Server Information
	**/
	public static $databaseLocal = 'STARS';
	public static $userLocal = 'root';
	public static $pswdLocal = 'hcilab300';
	public static $hostLocal = 'localhost';
	
	/** 
	* 		Remote Server Connection information
	**/
	public static $databaseRemote = 'starsall_jomsocial';
	public static $userRemote = 'stars_joms';
	public static $pswdRemote = 'PA:iRM8mh9%j';
	public static $hostRemote = 'sc-mysql-1.cuwqsdf6sh6w.us-east-1.rds.amazonaws.com';
	
	/**	
	*		Other
	**/
	
	public static $dateFormat = 'Y-m-d\TH-i-s'; // Standard XML time format.
}
?>	